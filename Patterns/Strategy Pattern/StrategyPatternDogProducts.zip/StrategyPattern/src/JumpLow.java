
public class JumpLow implements InterfaceJumping {

	@Override
	public void jump() {
		System.out.println("I am jumping low!");	
	}

}
