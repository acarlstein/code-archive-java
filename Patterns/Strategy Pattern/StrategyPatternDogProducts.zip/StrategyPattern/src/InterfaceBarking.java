
public interface InterfaceBarking {
	public void bark();
}

