
public interface InterfaceJumping {
	public void jump();
}
