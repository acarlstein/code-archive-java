
public class DoNotBark implements InterfaceBarking {

	@Override
	public void bark() {
		System.out.println("(I cannot bark :P) ...");	
	}

}
