
public class DoNotJump implements InterfaceJumping {

	@Override
	public void jump() {
		System.out.println("I cannot jump!");	
	}

}
