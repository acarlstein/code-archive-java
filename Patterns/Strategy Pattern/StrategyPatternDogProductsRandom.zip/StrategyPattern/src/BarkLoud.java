
public class BarkLoud implements InterfaceBarking {

	@Override
	public void bark() {
		System.out.println("I am barking loud! BARK! BARK! BARK!");	
	}

}
