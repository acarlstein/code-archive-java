
public class BarkSoft implements InterfaceBarking {

	@Override
	public void bark() {
		System.out.println("I am barking soft. JIP! JIP! JIP!");	
	}

}
